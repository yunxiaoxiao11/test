local db=function()
  local status,db=pcall(require,"dashboard")
  if not status then
    vim.nofigy("没有找到 dashboard")
    return
  end
  db.setup{
    theme='doom',
    config={
      header={
        [[]],
        [[]],
  [[               ▄▄██████████▄▄             ]],
  [[               ▀▀▀   ██   ▀▀▀             ]],
  [[       ▄██▄   ▄▄████████████▄▄   ▄██▄     ]],
  [[     ▄███▀  ▄████▀▀▀    ▀▀▀████▄  ▀███▄   ]],
  [[    ████▄ ▄███▀              ▀███▄ ▄████  ]],
  [[   ███▀█████▀▄████▄      ▄████▄▀█████▀███ ]],
  [[   ██▀  ███▀ ██████      ██████ ▀███  ▀██ ]],
  [[    ▀  ▄██▀  ▀████▀  ▄▄  ▀████▀  ▀██▄  ▀  ]],
  [[       ███           ▀▀           ███     ]],
  [[       ██████████████████████████████     ]],
  [[   ▄█  ▀██  ███   ██    ██   ███  ██▀  █▄ ]],
  [[   ███  ███ ███   ██    ██   ███▄███  ███ ]],
  [[   ▀██▄████████   ██    ██   ████████▄██▀ ]],
  [[    ▀███▀ ▀████   ██    ██   ████▀ ▀███▀  ]],
  [[     ▀███▄  ▀███████    ███████▀  ▄███▀   ]],
  [[       ▀███    ▀▀██████████▀▀▀   ███▀     ]],
  [[         ▀    ▄▄▄    ██    ▄▄▄    ▀       ]],
  [[               ▀████████████▀             ]],
  [[]],
  [[]],
      },
      center={
        {
          icon = '',
          icon_hl = 'group',
          desc = 'description',
          desc_hl = 'group',
          key = 'shortcut key in dashboard buffer not keymap !!',
          key_hl = 'group',
          action = '',
        },
      },
      footer={

      },
      packages={

      }
    }
  }
end
return db